"""
Title: Emulating Human-like Adaptive Oculomotor Mechanisms for Fast and Interpretable X-ray Reconstruction
Authors: [Your Name], et al.
Affiliation: [Your Institution]
Year: 2025

Description:
-------------------------------------
Biologically interpretable feature extractor for real-time and transparent X-ray reconstruction.
It integrates hierarchical cortical vision stages with adaptive oculomotor dynamics:
    - V1: Pixel completion
    - V2/V3: Structural inference
    - V4: Semantic abstraction (Mamba-Transformer hybrid)
    - IT: Holistic integration
    - MEGM: Macroscopic Eye Grouping Mechanism
    - MSRM: Microscopic Saccadic-like Rhythm Mechanism
-------------------------------------
Reference: "Emulating Human-like Adaptive Oculomotor Mechanisms for Fast and Interpretable X-ray Reconstruction", 2025
"""

import torch
import torch.nn as nn

# Try importing MambaBlock if available, else define fallback
try:
    from mamba_ssm import MambaBlock
except ImportError:
    class MambaBlock(nn.Module):
        def __init__(self, dim):
            super().__init__()
            self.proj = nn.Sequential(
                nn.Linear(dim, dim),
                nn.GELU(),
                nn.Linear(dim, dim)
            )
        def forward(self, x):
            return self.proj(x)


class V1_PixelCompletion(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.GELU()
        )
    def forward(self, x):
        return self.conv(x)


class V2V3_StructureInference(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.attn = nn.MultiheadAttention(dim, num_heads=4, batch_first=True)
        self.ffn = nn.Sequential(nn.Linear(dim, dim), nn.GELU(), nn.Linear(dim, dim))
    def forward(self, x):
        B, C, H, W = x.shape
        x_flat = x.flatten(2).permute(0, 2, 1)
        attn_out, _ = self.attn(x_flat, x_flat, x_flat)
        out = x_flat + self.ffn(attn_out)
        return out.permute(0, 2, 1).reshape(B, C, H, W)


class V4_SemanticAbstraction(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.mamba = MambaBlock(dim)
    def forward(self, x):
        B, C, H, W = x.shape
        x_flat = x.flatten(2).permute(0, 2, 1)
        out = self.mamba(x_flat)
        return out.permute(0, 2, 1).reshape(B, C, H, W)


class IT_HolisticIntegration(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.fc = nn.Sequential(
            nn.Linear(dim, dim),
            nn.GELU(),
            nn.Linear(dim, dim)
        )
    def forward(self, x):
        pooled = torch.mean(x.flatten(2), dim=2)
        out = self.fc(pooled)
        return out.unsqueeze(-1).unsqueeze(-1).expand_as(x)


class MEGM(nn.Module):
    def __init__(self, num_groups):
        super().__init__()
        self.num_groups = num_groups
        self.group_norms = nn.ModuleList([nn.GroupNorm(1, num_groups) for _ in range(num_groups)])
    def forward(self, x):
        groups = torch.chunk(x, self.num_groups, dim=1)
        processed = [gn(g) for gn, g in zip(self.group_norms, groups)]
        return torch.cat(processed, dim=1)


class MSRM(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.saccade = nn.Conv2d(dim, dim, 3, padding=1)
        self.fixation = nn.Identity()
        self.microsaccade = nn.Conv2d(dim, dim, 1)
        self.attn = nn.MultiheadAttention(dim, 4, batch_first=True)
    def forward(self, x):
        x = self.saccade(x) + self.microsaccade(x) + self.fixation(x)
        B, C, H, W = x.shape
        x_flat = x.flatten(2).permute(0, 2, 1)
        attn_out, _ = self.attn(x_flat, x_flat, x_flat)
        return attn_out.permute(0, 2, 1).reshape(B, C, H, W)


class BioVisionFeatureExtractor(nn.Module):
    def __init__(self, in_channels=3, dim=64):
        super().__init__()
        self.v1 = V1_PixelCompletion(in_channels, dim)
        self.megm = MEGM(num_groups=4)
        self.v2v3 = V2V3_StructureInference(dim)
        self.msrm = MSRM(dim)
        self.v4 = V4_SemanticAbstraction(dim)
        self.it = IT_HolisticIntegration(dim)

    def forward(self, x):
        x = self.v1(x)
        x = self.megm(x)
        x = self.v2v3(x)
        x = self.msrm(x)
        x = self.v4(x)
        x = self.it(x)
        return x
