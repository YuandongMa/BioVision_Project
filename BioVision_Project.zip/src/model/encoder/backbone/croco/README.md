Most of the code under src/model/encoder/backbone/croco/ is from the original CROCO implementation. 
The code is not modified in any way except the relative module path. 
The original code can be found at [croco Github Repo](https://github.com/naver/croco/tree/743ee71a2a9bf57cea6832a9064a70a0597fcfcb/models).


Except:
- 'misc.py', 'patch_embed.py' is from DUSt3R.